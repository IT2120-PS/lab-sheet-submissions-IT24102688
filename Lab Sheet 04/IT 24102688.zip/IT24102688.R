#1
setwd("C:\\Users\\IT24102688\\Desktop\\IT24102688")
branch_data <- read.table("C:\\Users\\IT24102688\\Desktop\\IT24102688\\Exersice.txt", header = TRUE, sep = "\t")
head(branch_data)

#2
sapply(branch_data, class)

scale_of_measurement <- c(
  Age = "Ratio",
  Gender = "Nominal",
  Income = "Ratio",
  Education = "Ordinal",
  City = "Nominal"
)

print(scale_of_measurement)

#3
boxplot(Sales_X1, main="Boxplot for Sales", horizontal=TRUE)
#4
summary(Advertising_X2)
IQR(Advertising_X2)
#5
get_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5 * iqr
  lb <- q1 - 1.5 * iqr
  outliers <- sort(z[z < lb | z > ub])
  return(outliers)
}

get_outliers(Years_X3)