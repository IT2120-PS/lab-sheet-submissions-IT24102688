#1
setwd("C://Users//it24102688//Desktop//IT24102688")
Delivery_Time<-read.table("Exercise - Lab 05.txt",header=TRUE)
attach(Delivery_Time)
names(Delivery_Time) <-c("x1")
attach(Delivery_Time)

#2
histogram<-hist(x1,main = "Histogram for Delivery Time",breaks = seq(20,70,length= 10),right = TRUE)

#3-Symmetric distribution

#4

cumulative_freq <- cumsum(histogram$counts)
plot(histogram$mids, cumulative_freq, type="o", xlab="Delivery Time", ylab="Cumulative Frequency", 
     main="Cumulative Frequency Polygon (Ogive)", lwd=2)